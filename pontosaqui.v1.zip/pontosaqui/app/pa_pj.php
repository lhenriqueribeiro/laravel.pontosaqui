<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class pa_pj extends Model
{
    //
}
