<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class pa_pf extends Model
{
    //
}
