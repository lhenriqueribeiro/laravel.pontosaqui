<?php

namespace App\Http\Controllers;

use App\pa_pf;
use Illuminate\Http\Request;

class PaPfController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\pa_pf  $pa_pf
     * @return \Illuminate\Http\Response
     */
    public function show(pa_pf $pa_pf)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\pa_pf  $pa_pf
     * @return \Illuminate\Http\Response
     */
    public function edit(pa_pf $pa_pf)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\pa_pf  $pa_pf
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, pa_pf $pa_pf)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\pa_pf  $pa_pf
     * @return \Illuminate\Http\Response
     */
    public function destroy(pa_pf $pa_pf)
    {
        //
    }
}
