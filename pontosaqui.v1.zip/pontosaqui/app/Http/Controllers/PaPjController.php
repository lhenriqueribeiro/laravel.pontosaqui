<?php

namespace App\Http\Controllers;

use App\pa_pj;
use Illuminate\Http\Request;

class PaPjController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\pa_pj  $pa_pj
     * @return \Illuminate\Http\Response
     */
    public function show(pa_pj $pa_pj)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\pa_pj  $pa_pj
     * @return \Illuminate\Http\Response
     */
    public function edit(pa_pj $pa_pj)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\pa_pj  $pa_pj
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, pa_pj $pa_pj)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\pa_pj  $pa_pj
     * @return \Illuminate\Http\Response
     */
    public function destroy(pa_pj $pa_pj)
    {
        //
    }
}
